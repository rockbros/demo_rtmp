#include "audioencoderabstract.h"

AudioEncoderAbstract::AudioEncoderAbstract()
{
    m_samplerate    =  0 ;
    m_channels      =  0 ;
    m_bitrate       =  0 ;
}

AudioEncoderAbstract::~AudioEncoderAbstract()
{

}

